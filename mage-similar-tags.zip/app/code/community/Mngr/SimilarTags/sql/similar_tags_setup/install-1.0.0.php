<?php
$this->startSetup();

$table = $this->getConnection()
    ->newTable($this->getTable(array('similar_tags', 'product_similarity')))
    ->addColumn(
        'id', Varien_Db_Ddl_Table::TYPE_INTEGER, null,
        array(
            'identity' => true,
            'unsigned' => true,
            'nullable' => false,
            'primary' => true),
        'Record ID')
    ->addColumn(
        'product_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null,
        array(
            'unsigned' => true,
            'nullable' => false),
        'Product ID')
    ->addColumn(
        'similar_product_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null,
        array(
            'unsigned' => true,
            'nullable' => false),
        'Product ID to compare')
    ->addColumn(
        'store_id', Varien_Db_Ddl_Table::TYPE_SMALLINT, null,
        array(
            'unsigned' => true,
            'nullable' => false,
            'default' => '0'),
        'Store ID')
    ->addColumn(
        'similarity', Varien_Db_Ddl_Table::TYPE_DECIMAL, array(12, 4),
        array(),
        'Similarity value')
    ->addIndex(
        $this->getIdxName(
            'similar_tags/product_similarity',
            array('product_id', 'similar_product_id', 'store_id'),
            Varien_Db_Adapter_Interface::INDEX_TYPE_UNIQUE),
        array('product_id', 'similar_product_id', 'store_id'),
        array('type' => Varien_Db_Adapter_Interface::INDEX_TYPE_UNIQUE))
    ->addIndex(
        $this->getIdxName(
            'similar_tags/product_similarity', array('product_id')),
        array('product_id'))
    ->addIndex(
        $this->getIdxName(
            'similar_tags/product_similarity', array('similar_product_id')),
        array('similar_product_id'))
    ->addIndex(
        $this->getIdxName(
            'similar_tags/product_similarity', array('store_id')),
        array('store_id'))
    ->addForeignKey(
        $this->getFkName(
            'similar_tags/product_similarity', 'product_id',
            'catalog/product', 'entity_id'),
        'product_id',
        $this->getTable('catalog/product'), 'entity_id',
        Varien_Db_Ddl_Table::ACTION_CASCADE, Varien_Db_Ddl_Table::ACTION_CASCADE)
    ->addForeignKey(
        $this->getFkName(
            'similar_tags/product_similarity', 'similar_product_id',
            'catalog/product', 'entity_id'),
        'similar_product_id',
        $this->getTable('catalog/product'), 'entity_id',
        Varien_Db_Ddl_Table::ACTION_CASCADE, Varien_Db_Ddl_Table::ACTION_CASCADE)
    ->addForeignKey(
        $this->getFkName(
            'similar_tags/product_similarity', 'store_id',
            'core/store', 'store_id'),
        'store_id', $this->getTable('core/store'), 'store_id')
    ->setComment('Product similarity index table');
$this->getConnection()->createTable($table);

$this->endSetup();