<?php
class Mngr_SimilarTags_Helper_Data
extends Mage_Core_Helper_Abstract
{
    const XML_PATH_TAGS = 'catalog/similar_tags/tags';

    public function getTags($store = null)
    {
        $serializedValue = Mage::getStoreConfig(self::XML_PATH_TAGS, $store);
        $value = @unserialize($serializedValue);
        $tags = array();
        if (is_array($value)) {
            foreach ($value as $row) {
                if (!isset($row['tag'])) continue;
                $tags[] = $row['tag'];
            }
        }
        return $tags;
    }

}