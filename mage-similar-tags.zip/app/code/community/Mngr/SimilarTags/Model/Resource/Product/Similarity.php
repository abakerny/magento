<?php
class Mngr_SimilarTags_Model_Resource_Product_Similarity
extends Mage_Core_Model_Resource_Db_Abstract
{
    protected function _construct()
    {
        $this->_init('similar_tags/product_similarity', 'id');
    }

    public function deleteNotTagged($storeId)
    {

        $write = $this->_getWriteAdapter();
        $relationTable = Mage::getResourceModel('tag/tag_relation')
            ->getMainTable();
        $tagTable = Mage::getResourceModel('tag/tag')
            ->getMainTable();

        $taggedSelect = $write->select()
            ->distinct()
            ->from(
                array('relation' => $relationTable),
                array('product_id' => 'product_id'));
        $tags = Mage::helper('similar_tags')->getTags($storeId);
        $joinConds = array(
            'tag.tag_id = relation.tag_id',
            $write->quoteInto(
                'tag.status = ?', Mage_Tag_Model_Tag::STATUS_APPROVED),
            $write->quoteInto('tag.name IN (?)', $tags));
        $taggedSelect->join(
                array('tag' => $tagTable),
                '(' . implode(') AND (', $joinConds) . ')',
                array());
        $taggedSelect->where('relation.store_id = ?', $storeId);

        $storeIdCond = $write->quoteInto('store_id = ?', $storeId);
        $sql = 'DELETE FROM '
            . $write->quoteIdentifier($this->getMainTable())
            . ' WHERE ' . $storeIdCond
            . '  AND ('
            . '   product_id NOT IN (' . (string)$taggedSelect . ')'
            . '   OR similar_product_id NOT IN ('. (string)$taggedSelect . ')'
            . '  )';
        $write->query($sql);
    }

    public function saveDataBundle(array $data)
    {
        if (empty($data)) return $this;

        $dataPositive = array_filter($data, array($this, '_isDataPositive'));
        $dataZero = array_filter($data, array($this, '_isDataZero'));
        $write = $this->_getWriteAdapter();

        // insert/update positive values
        if (!empty($dataPositive)) {
            $sql = 'INSERT INTO '
                . $write->quoteIdentifier($this->getMainTable()) . ' '
                . '(product_id, similar_product_id, store_id, similarity) '
                . 'VALUES ';
            $valueStrings = array();
            foreach ($dataPositive as $row) {
                array_walk($row, array($write, 'quote'));
                $valueStrings[] = sprintf(
                    '(%s, %s, %s, %s)',
                    $row['product_id'], $row['similar_product_id'],
                    $row['store_id'],
                    $row['similarity']);
            }
            $sql .= implode(', ', $valueStrings) . ' ';
            $sql .= 'ON DUPLICATE KEY UPDATE similarity = VALUES(similarity)';
            $write->query($sql);
        }

        // remove zero values
        if (!empty($dataZero)) {
            $sql = 'DELETE FROM '
                . $write->quoteIdentifier($this->getMainTable()) . ' '
                . 'WHERE ';
            $whereOr = array();
            foreach ($dataZero as $row) {
                $whereOr[] = '('
                    . $write->quoteInto(
                        'product_id = ?', $row['product_id'])
                    . ' AND '
                    . $write->quoteInto(
                        'similar_product_id = ?', $row['similar_product_id'])
                    . ')';
            }
            $sql .= implode(' OR ', $whereOr);
            $write->query($sql);
        }
    }

    protected function _isDataPositive(array $row)
    {
        return isset($row['similarity']) && ($row['similarity'] > 0);
    }

    protected function _isDataZero(array $row)
    {
        return !$this->_isDataPositive($row);
    }

}