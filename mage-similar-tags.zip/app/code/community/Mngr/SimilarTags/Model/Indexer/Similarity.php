<?php
class Mngr_SimilarTags_Model_Indexer_Similarity
extends Mage_Index_Model_Indexer_Abstract
{
    const SAVE_BUNDLE_SIZE = 100;
    const CACHE_TAG = 'similar_tags_similarity';
    const PROCESS_CODE = 'similar_tags_similarity';
    const EVENT_PRODUCT_IDS_KEY = 'similar_tags_product_ids';
    const EVENT_STORE_IDS_KEY = 'similar_tags_store_id';

    protected $_matchedEntities = array(
        Mage_Tag_Model_Tag::ENTITY => array(
            Mage_Index_Model_Event::TYPE_SAVE),
        Mage_Tag_Model_Tag_Relation::ENTITY => array(
            Mage_Index_Model_Event::TYPE_SAVE),
        Mngr_SimilarTags_Model_Adminhtml_System_Config_Backend_Tags::INDEX_ENTITY => array(
        Mage_Index_Model_Event::TYPE_SAVE));

    protected $_tagIds = array();
    protected $_taggedProductIds = array();
    protected $_productTagIds = array();
    protected $_updatedProductMarks = array();
    protected $_dataToSave = array();

    public function getName()
    {
        return Mage::helper('similar_tags')->__('Product tag list similarity');
    }

    public function getDescription()
    {
        return Mage::helper('similar_tags')->__('Product tag list similarity');
    }

    public function reindexAll()
    {
        try {
            $this->_startUpdate();
            $stores = Mage::app()->getStores(Mage::app()->isSingleStoreMode());
            foreach ($stores as $store)
                $this->_updateStore($store->getId());
            $this->_finishUpdate();
            $this->_cleanCache();

        } catch (Exception $e) {
            // log and re-throw exception
            Mage::logException($e);
            throw $e;
        }
    }

    protected function _registerEvent(Mage_Index_Model_Event $event)
    {
        switch ($event->getEntity()) {
            case Mage_Tag_Model_Tag::ENTITY:
                $tag = $event->getDataObject();
                $event->addNewData(
                    self::EVENT_STORE_IDS_KEY,
                    array($tag->getStoreId()));
                if ($tag->hasData('tag_assigned_products'))
                    $event->addNewData(
                        self::EVENT_PRODUCT_IDS_KEY,
                        $tag->getData('tag_assigned_products'));
                break;

            case Mage_Tag_Model_Tag_Relation::ENTITY:
                $relation = $event->getDataObject();
                $event->addNewData(
                    self::EVENT_STORE_IDS_KEY,
                    array($relation->getStoreId()));
                $event->addNewData(
                    self::EVENT_PRODUCT_IDS_KEY,
                    array($relation->getProductId()));
                break;

            case Mngr_SimilarTags_Model_Adminhtml_System_Config_Backend_Tags::INDEX_ENTITY:
                break;
        }
    }

    protected function _processEvent(Mage_Index_Model_Event $event)
    {
        $this->_startUpdate();
        $data = $event->getNewData();
        $storeIds = isset($data[self::EVENT_STORE_IDS_KEY])
            ? (array)$data[self::EVENT_STORE_IDS_KEY] : array();
        $productIds = isset($data[self::EVENT_PRODUCT_IDS_KEY])
            ? (array)$data[self::EVENT_PRODUCT_IDS_KEY]
            : array();

        // update all stores if no store IDs specified
        if (empty($storeIds)) {
            $stores = Mage::app()->getStores(Mage::app()->isSingleStoreMode());
            foreach ($stores as $store)
                $storeIds[] = $store->getId();
        }

        foreach ($storeIds as $storeId) {
            if (empty($productIds))
                $productIds = $this->_getTaggedProductIds($storeId);
            foreach ($productIds as $productId)
                $this->_updateProduct($storeId, $productId);
            $this->_deleteNotTagged($storeId);
        }
        $this->_finishUpdate();
        $this->_cleanCache($storeId);
    }

    protected function _startUpdate()
    {
    }

    protected function _finishUpdate()
    {
        $this->_resetCache();
        $this->_saveData(true);
    }

    protected function _updateStore($storeId)
    {
        $productIds = $this->_getTaggedProductIds($storeId);
        foreach ($productIds as $productId)
            $this->_updateProduct($storeId, $productId);
        $this->_deleteNotTagged($storeId);
    }

    protected function _updateProduct($storeId, $productId)
    {
        $similarProductIds = $this->_getTaggedProductIds($storeId);
        foreach ($similarProductIds as $similarProductId) {
            if ($similarProductId == $productId) continue;
            if ($this->_isProductUpdated($storeId, $similarProductId)) continue;

            $similarity = $this->_calcTagVectorSimilarity(
                $this->_getProductTagIds($storeId, $productId),
                $this->_getProductTagIds($storeId, $productId));
            $this->_addDataToSave(
                array(
                    'product_id' => $productId,
                    'similar_product_id' => $similarProductId,
                    'store_id' => $storeId,
                    'similarity' => $similarity));
            $this->_addDataToSave(
                array(
                    'product_id' => $similarProductId,
                    'similar_product_id' => $productId,
                    'store_id' => $storeId,
                    'similarity' => $similarity));
        }
        $this->_markProductUpdated($storeId, $productId);
    }

    protected function _cleanCache($storeId = null)
    {
        if (is_null($storeId)) {
            Mage::app()->cleanCache(self::CACHE_TAG);
        } else {
            Mage::app()->cleanCache(self::CACHE_TAG.$storeId);
        }
    }

    protected function _getTaggedProductIds($storeId)
    {
        if (!isset($this->_taggedProductIds[$storeId])) {
            $tagRelTable = Mage::getResourceModel('tag/tag_relation')
                ->getMainTable();
            $select = $this->_getReadAdapter()->select()
                ->distinct(true)
                ->from(
                    array('tag_rel' => $tagRelTable),
                    array('product_id'))
                ->where('active')
                ->where('store_id = ?', $storeId)
                ->where('tag_id IN (?)', $this->_getTagIds($storeId));
            $productIds = $this->_getReadAdapter()->fetchCol($select);
            $this->_taggedProductIds[$storeId] = $productIds;
        }
        return $this->_taggedProductIds[$storeId];
    }

    protected function _deleteNotTagged($storeId)
    {
        $this->_getResource()->deleteNotTagged($storeId);
    }

    protected function _getProductTagIds($storeId, $productId)
    {
        if (!isset($this->_productTagIds[$storeId])
            || !isset($this->_productTagIds[$storeId][$productId])
        ) {
            $tagRelTable = Mage::getResourceModel('tag/tag_relation')
                ->getMainTable();
            $select = $this->_getReadAdapter()->select()
                ->from(
                    array('tag_rel' => $tagRelTable),
                    array('tag_id'))
                ->where('active')
                ->where('store_id = ?', $storeId)
                ->where('product_id = ?', $productId);
            $tagIds = $this->_getReadAdapter()->fetchCol($select);
            if (!isset($this->_productTagIds[$storeId]))
                $this->_productTagIds[$storeId] = array();
            $this->_productTagIds[$storeId][$productId] = $tagIds;
        }
        return $this->_productTagIds[$storeId][$productId];
    }

    protected function _getTagIds($storeId)
    {
        if (!isset($this->_tagIds[$storeId])) {
            $tags = Mage::helper('similar_tags')->getTags($storeId);
            if (empty($tags)) {
                $this->_tagIds[$storeId] = array();
            } else {
                $tagCollection = Mage::getResourceModel('tag/tag_collection')
                    ->addStatusFilter(Mage_Tag_Model_Tag::STATUS_APPROVED)
                    ->addFieldToFilter('name', $tags);
                $this->_tagIds[$storeId] = array();
                foreach ($tagCollection as $tag)
                    $this->_tagIds[$storeId][] = $tag->getId();
            }
        }
        return $this->_tagIds[$storeId];
    }

    protected function _addDataToSave($row)
    {
        $this->_dataToSave[] = $row;
        $this->_saveData();
    }

    protected function _saveData($force = false)
    {
        if ($force || count($this->_dataToSave >= self::SAVE_BUNDLE_SIZE)) {
            $this->_getResource()->saveDataBundle($this->_dataToSave);
            $this->_dataToSave = array();
        }
    }

    protected function _isProductUpdated($storeId, $productId)
    {
        return isset($this->_updatedProductMarks[$storeId])
            && isset($this->_updatedProductMarks[$storeId][$productId]);
    }

    protected function _markProductUpdated($storeId, $productId)
    {
        if (!isset($this->_updatedProductMarks[$storeId]))
            $this->_updatedProductMarks[$storeId] = array();
        $this->_updatedProductMarks[$storeId][$productId] = true;
    }

    protected function _calcTagVectorSimilarity($tagIds, $similarTagIds)
    {
        $intersectCount = count(array_intersect($tagIds, $similarTagIds));
        $dotProd = $intersectCount;
        if ($dotProd == 0)
            return 0;
        $lengthProd = sqrt(count($tagIds)) * sqrt(count($similarTagIds));
        $similarity = (100 * $dotProd / $lengthProd)
            * (1 + log($intersectCount));
        return $similarity;
    }

    protected function _getReadAdapter()
    {
        return Mage::getSingleton('core/resource')->getConnection('read');
    }

    protected function _getResource()
    {
        return Mage::getResourceSingleton('similar_tags/product_similarity');
    }

    protected function _resetCache()
    {
        $this->_tagIds = array();
        $this->_productTagIds = array();
        $this->_updatedProductMarks = array();
    }

}