<?php
class Mngr_SimilarTags_Model_Adminhtml_System_Config_Backend_Tags
extends Mage_Adminhtml_Model_System_Config_Backend_Serialized_Array
{
    const INDEX_ENTITY = 'config_tag_list';

    protected function _beforeSave()
    {
        if ($this->isValueChanged()) {
            $data = new Varien_Object();
            Mage::getSingleton('index/indexer')->logEvent(
                $data, self::INDEX_ENTITY, Mage_Index_Model_Event::TYPE_SAVE);
        }
        parent::_beforeSave();
    }
}